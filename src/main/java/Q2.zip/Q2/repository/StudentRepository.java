package Q2.repository;
import Q2.entity.Student;

public interface StudentRepository extends PersonRepository<Student> {

}
