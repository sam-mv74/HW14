package Q2.repository;
import Q2.entity.Teacher;

public interface TeacherRepository extends PersonRepository<Teacher>{
}
