package Q2.entity;

public enum TeacherGrade {
    ASSOCIATE, BACHELOR, MASTER, DOCTORAL
}
